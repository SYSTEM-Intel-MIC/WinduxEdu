# ElevenDE 3.5.1 测试说明

ElevenDE 3.5.1 在 Ubuntu 24.04 的 Xvfb + Openbox 无头 X11 环境中进行构建和发布前回归。本轮重点验证 **Lindows 资源管理器命名**、所有内置应用的第一方窗口图标、任务栏的主题图标优先级与黑色占位图过滤，以及锁屏/SAS 内部窗口不再被误放入右下角托盘。测试脚本属于发布工程的验证资产；源码包保留可复现构建所需的 `build-deb.sh` 与 `install.sh`，DEB 中也会安装这两份脚本和本说明。

| 测试项 | 验证方法 | 结果 |
|---|---|---|
| 完整构建与打包 | `sudo ./build-deb.sh` 编译 Shell、锁屏、通知服务、Explorer、SAS、RunBox 和 Qt 应用套件，并生成 3.5.1 DEB。 | 通过 |
| DEB 元数据与内容 | 使用 `dpkg-deb -f` 和 `dpkg-deb -c` 核验版本、依赖、核心可执行文件、图标主题、README、TESTING 及构建脚本。 | 通过 |
| 任务栏与窗口图标 | 在 Xvfb + Openbox 中启动计算器、设置、任务管理器、记事本与 Lindows 资源管理器，检查每个窗口都有 `_NET_WM_ICON`，并保存实际任务栏截图。 | 通过 |
| Lindows 命名 | 用窗口标题搜索资源管理器，确认标题包含“Lindows 资源管理器”，且任务栏图标回归脚本可稳定定位。 | 通过 |
| 黑色占位图过滤 | 任务栏图标解析先命中 ElevenDE 主题；纯黑/近黑 `_NET_WM_ICON` 会被拒绝并回退到受控主题图标。 | 通过 |
| 锁托盘过滤 | 对根窗口树执行锁/SAS 名称检查；任务栏回归截图和窗口树均未出现锁屏/SAS 托盘项。 | 通过 |
| 资源管理器命令栏 | 在真实 Openbox 框架内点击“新建”整按钮和菜单第一项；测试文件夹被成功创建，并保存命令栏截图。 | 通过 |
| 桌面热刷新 | 运行中的 Shell 外部创建桌面文件、原子替换壁纸后分别捕获截图；Shell 无需重启即可刷新。 | 通过 |
| 登录密码框 | 真实鼠标移入和点击密码框；跨六帧采样检测到两个光标相位，确认 I-beam、焦点边框与双缓冲闪烁光标路径。 | 通过 |
| 应用客户区输入 | 新编译记事本在点击编辑区后可输入、全选复制并以 `UTF8_STRING` 从剪贴板读取文本。 | 通过 |
| 标题栏交互 | 在 ElevenDE Openbox 主题下回归标题栏拖动；窗口可从标题栏移动。最大化、最小化和关闭继续由标准 Openbox `Press` + `Click` 绑定提供。 | 通过 |
| WLAN、显示桌面与 SAS | 保留既有任务栏网络入口、显示桌面细条与 SAS 覆盖层验证；本轮图标更新未改动对应路由。 | 通过 |

> **硬件说明**：无头构建环境没有可连接的物理无线网卡，因此不会尝试连接真实 AP。WLAN 面板的扫描、密码与连接命令路径使用项目现有的 `nmcli`/iwd 实现；安装包声明 `network-manager | iwd` 运行时依赖。请在目标机器上用真实无线网卡完成最终网络兼容性验收。

## 发布前复现

```sh
chmod +x build-deb.sh
sudo ./build-deb.sh
dpkg-deb -f elevende_3.5.1_amd64.deb Package Version Architecture Depends
sudo apt install ./elevende_3.5.1_amd64.deb
```

安装后可在显示管理器中选择 **ElevenDE** 会话，或执行以下命令手动启动：

```sh
startx /usr/local/bin/elevende-session
```

对升级系统，安装后重新登录即可使新任务栏图标主题、Lindows 资源管理器命名和锁托盘过滤逻辑生效；无需删除用户配置。
