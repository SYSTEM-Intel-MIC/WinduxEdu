# RunBox —— 在 Linux 上找回 Win+R

RunBox 是一个 Linux 上的 Windows 风格「运行」对话框。按下 **Win+R**（Super+R），
弹出和 Windows 几乎一模一样的运行窗口，输入命令回车即运行。

## 特性

- 🪟 **界面高度还原 Windows「运行」对话框**：白色标题栏、蓝色图标、
  "输入程序、文件夹、文档或互联网资源的名称……" 提示文字、确定/取消/浏览三按钮
- ⌨️ **全局快捷键 Win+R**：安装脚本自动适配 GNOME / XFCE 等桌面；
  其他 X11 环境自动启用后台守护进程
- 🕘 **历史命令记忆**：输入框带下拉历史（最多 25 条），和 Windows 一样越用越顺手
- 🪟 **Windows 常用命令别名**：`cmd`、`notepad`、`calc`、`control`、`explorer`、`taskmgr`
  自动映射到 Linux 上对应的程序
- 🔗 **智能识别输入**：网址自动用浏览器打开；文件/文件夹路径自动用默认程序打开
- 🔐 **可选管理员运行 / 终端运行**：两个复选框搞定（pkexec / 自动包一层终端）
- 📦 **一键傻瓜式安装**：`./install.sh` 自动装依赖、编译、安装、绑定快捷键

## 一键安装（推荐）

解压后进入目录，执行：

```bash
./install.sh
```

脚本会自动完成：

1. 检测发行版并安装编译依赖（支持 apt / dnf / yum / pacman / zypper / apk）
2. 编译 RunBox
3. 安装到 `/usr/local`（自动调用 sudo）
4. 绑定全局快捷键 **Super+R**：
   - GNOME / Unity / Budgie 等：自动写入自定义快捷键
   - XFCE：自动写入 xfconf
   - 其他 X11 环境：自动启动 `runbox --daemon` 守护进程并加入开机自启
   - KDE Wayland 等无法自动绑定的环境：给出手动绑定提示

安装完成后，按 **Win+R** 即可。

> 请以**普通用户**身份运行脚本（不要用 root / sudo ./install.sh），
> 因为快捷键必须绑定到当前桌面用户。

## 手动编译安装

```bash
make
sudo make install
```

依赖：`gcc`、`make`、`pkg-config`、GTK3 开发包、libX11 开发包、`xdg-utils`。

## 使用方法

| 操作 | 效果 |
| --- | --- |
| Win+R | 呼出运行对话框 |
| 输入命令 + 回车 / 点「确定」 | 运行程序 |
| Esc / 点「取消」 | 关闭窗口 |
| 「浏览」按钮 | 选择文件并自动填入路径 |
| 勾选「在终端中运行」 | 在终端窗口中运行（适合命令行程序） |
| 勾选「以管理员身份运行」 | 通过 pkexec 提权运行 |

### Windows 命令对照表

在 RunBox 里直接输入这些 Windows 命令也能用：

| Windows 命令 | 自动打开的 Linux 程序（按顺序探测） |
| --- | --- |
| `cmd` | gnome-terminal / konsole / xfce4-terminal / tilix / xterm 等 |
| `notepad` | gedit / kate / mousepad / pluma / xed 等 |
| `calc` | gnome-calculator / kcalc / galculator 等 |
| `control` | gnome-control-center / systemsettings / xfce4-settings-manager 等 |
| `explorer` | nautilus / dolphin / thunar / caja / pcmanfm |
| `taskmgr` | gnome-system-monitor / plasma-systemmonitor / xfce4-taskmanager 等 |

### 输入识别规则

- `http://`、`https://`、`www.` 开头 → 默认浏览器打开
- 包含 `/` 或以 `~` 开头且路径存在 → 用默认程序打开（等同 Windows 打开文档）
- 其他 → 当作命令执行（支持参数，如 `firefox --private-window`）

## 卸载

```bash
./uninstall.sh
```

会移除程序文件、快捷键绑定、守护进程、开机自启项和历史记录。

## 常见问题

**按 Win+R 没反应？**

- GNOME 用户：确认没有与其他扩展/快捷键冲突；可运行
  `gsettings list-recursively org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/runbox/` 检查绑定。
- 其他桌面：在系统设置的快捷键里手动把命令 `runbox` 绑定到 Super+R，
  或运行 `runbox --daemon`（X11）。
- Wayland 下第三方程序无法抢注全局按键，必须走桌面环境自身的快捷键设置。

**提示 Super+R 已被占用？**

说明桌面环境或其他软件已使用该按键，可换绑其他按键，
或修改/停用占用方。

**输入的命令找不到？**

RunBox 使用你的 `PATH` 查找程序。图形界面启动的进程 PATH 可能比终端里少，
必要时请写完整路径。

## 目录结构

```
runbox/
├── install.sh          # 一键安装
├── uninstall.sh        # 一键卸载
├── Makefile            # 编译 / 安装规则
├── LICENSE             # MIT
├── README.md
├── src/
│   └── runbox.c        # 全部源码（单文件，GTK3 + X11）
└── data/
    ├── runbox.desktop  # 应用菜单项
    └── runbox.svg      # 图标
```

## 许可证

MIT
